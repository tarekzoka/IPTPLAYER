# -*- coding: utf-8 -*-
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerwidget import IPTVPlayerWidget
from Plugins.Extensions.IPTVPlayer.components.iptvconfigmenu import ConfigMenu
from Plugins.Extensions.IPTVPlayer.components.iptvpin import IPTVPinWidget
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _, IPTVPlayerNeedInit
from Plugins.Extensions.IPTVPlayer.setup.iptvsetupwidget import IPTVSetupMainWidget
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import IsExecutable, IsWebInterfaceModuleAvailable
###################################################

###################################################
# FOREIGN import
###################################################
from enigma import getDesktop
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Tools.BoundFunction import boundFunction
from Components.config import config
from Tools.Directories import resolveFilename, fileExists, SCOPE_PLUGINS
###################################################

####################################################
# Wywołanie wtyczki w roznych miejscach
####################################################
def Plugins(**kwargs):
    screenwidth = getDesktop(0).size().width()
    if screenwidth and screenwidth == 1920: iconFile = "icons/iptvlogohd.png"
    else: iconFile = "icons/iptvlogo.png"
    desc = _("Watch video materials from IPTV services")
    list = []
    if config.plugins.iptvplayer.plugin_autostart.value:
        list.append(PluginDescriptor(name=(_("IPTV Player")), description=desc, where = [PluginDescriptor.WHERE_WIZARD], fnc=(9, pluginAutostart), needsRestart=False))
    list.append(PluginDescriptor(name=(_("IPTV Player")), description=desc, where = [PluginDescriptor.WHERE_PLUGINMENU], icon=iconFile, fnc=main)) # always show in plugin menu
    list.append(PluginDescriptor(name=(_("IPTV Player")), description=desc, where = PluginDescriptor.WHERE_MENU, fnc=startIPTVfromMenu))
    if config.plugins.iptvplayer.showinextensions.value:
        list.append (PluginDescriptor(name=(_("IPTV Player")), description=desc, where = [PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main))
    if  IsWebInterfaceModuleAvailable() and config.plugins.iptvplayer.IPTVWebIterface.value:
        try:
            list.append(PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=False)) # activating IPTV web interface
        except Exception:
            print "IPTVplayer Exception appending PluginDescriptor.WHERE_SESSIONSTART descriptor."
    return list

####################################################
# Konfiguracja wtyczki
####################################################

#from __init__ import _

def startIPTVfromMenu(menuid, **kwargs):
    if menuid == "system":
        return [(_("Configure IPTV Player"), mainSetup, "iptv_config", None)]
    elif menuid == "mainmenu" and config.plugins.iptvplayer.showinMainMenu.value == True:
        return [("IPTV Player", main, "iptv_main", None)]
    else:
        return []
    
def mainSetup(session,**kwargs):
    if config.plugins.iptvplayer.configProtectedByPin.value:
        session.openWithCallback(boundFunction(pinCallback, session, runSetup), IPTVPinWidget, title=_("Enter pin")) 
    else:
        runSetup(session)
    
def runSetup(session):
    session.open(ConfigMenu) 

def main(session,**kwargs):
    if config.plugins.iptvplayer.pluginProtectedByPin.value:
        session.openWithCallback(boundFunction(pinCallback, session, runMain), IPTVPinWidget, title =_("Enter pin")) 
    else:
        runMain(session)
        
class pluginAutostart(Screen):
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        self.onShow.append(self.onStart)
    
    def onStart(self):
        self.onShow.remove(self.onStart)
        runMain(self.session, self.iptvDoRunMain)
        
    def iptvDoRunMain(self, session):
        session.openWithCallback(self.iptvDoClose, IPTVPlayerWidget)
        
    def iptvDoClose(self, **kwargs):
        self.close()
    
def doRunMain(session):
    session.open(IPTVPlayerWidget)

def runMain(session, nextFunction=doRunMain):
    wgetpath     = IsExecutable(config.plugins.iptvplayer.wgetpath.value)
    rtmpdumppath = IsExecutable(config.plugins.iptvplayer.rtmpdumppath.value)
    f4mdumppath  = IsExecutable(config.plugins.iptvplayer.f4mdumppath.value)
    platform     = config.plugins.iptvplayer.plarform.value
    if platform in ["auto", "unknown"] or not wgetpath or not rtmpdumppath or not f4mdumppath:
        session.openWithCallback(boundFunction(nextFunction, session), IPTVSetupMainWidget)
    elif IPTVPlayerNeedInit():
        session.openWithCallback(boundFunction(nextFunction, session), IPTVSetupMainWidget, True)
    else:
        nextFunction(session)
        
def pinCallback(session, callbackFun, pin=None):
    if None == pin: return
    if pin != config.plugins.iptvplayer.pin.value:
        session.open(MessageBox, _("Pin incorrect!"), type = MessageBox.TYPE_INFO, timeout = 5)
        return
    callbackFun(session)
    
def sessionstart(reason, **kwargs):
    if reason == 0 and 'session' in kwargs:
        try:
            import Plugins.Extensions.IPTVPlayer.Web.initiator
        except Exception, e:
            print "EXCEPTION initiating IPTVplayer WebComponent:", str(e)
